# gsb-php-VerEtudt
Cas à développer avec le pattern MVC.

